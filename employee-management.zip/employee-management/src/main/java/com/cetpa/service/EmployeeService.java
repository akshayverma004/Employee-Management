package com.cetpa.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.cetpa.entity.Employee;
import com.cetpa.repository.EmployeeRepository;

public class EmployeeService 
{
	private EmployeeRepository employeeRepository;
	
	public EmployeeService() 
	{
		employeeRepository=new EmployeeRepository();
	}
	public void saveRecord(HttpServletRequest request) 
	{
		Employee employee=new Employee();
		employee.setEid(Integer.parseInt(request.getParameter("eid")));
		employee.setFirstname(request.getParameter("firstname"));
		employee.setLastname(request.getParameter("lastname"));
		employee.setPhone(request.getParameter("phone"));
		employee.setEmail(request.getParameter("email"));
		employee.setDepartment(request.getParameter("department"));
		employee.setSalary(Integer.parseInt(request.getParameter("salary")));
		
		employeeRepository.saveEmployee(employee);
		int eid = Integer.parseInt(request.getParameter("eid"));
		updateRecord(eid, employee);
		
	}
	public List<Employee> getList()
	{
		return employeeRepository.getEmployeeList();
	}
	public Employee getRecord(int eid) 
	{
		return employeeRepository.getEmployee(eid);
	}
	public void deleteRecord(int eid) 
	{
		Employee employee= employeeRepository.getEmployee(eid);
		employeeRepository.deleteEmployee(employee);
	}
	public Employee updateRecord(int eid, Employee employee) {
		return employeeRepository.updateEmployee(eid, employee);
	}
}
