package com.cetpa.repository;

import java.util.List;

import org.hibernate.*;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cetpa.entity.Employee;

public class EmployeeRepository 

{
	private Session session;
	private Transaction transaction;
	
	public EmployeeRepository() 
	{
		SessionFactory sessionFactory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		session=sessionFactory.openSession();
		transaction=session.getTransaction();
	}
	 public void saveEmployee(Employee employee) 
	 {
		 transaction.begin();
		 session.persist(employee);
		 transaction.commit();
	 }
	 public List<Employee> getEmployeeList()
	 {
		 Query<Employee> query=session.createQuery("from Employee",Employee.class);
		 List<Employee> employeeList=query.list();
		 return employeeList;	 
	 }
	 public Employee getEmployee(int eid) 
	 {
		Employee employee=session.get(Employee.class,eid) ;
		return employee;		 
	 }
	 public void deleteEmployee(Employee employee) 
	 {
		 transaction.begin();
		 session.delete(employee);
		 transaction.commit();
	 }
	 public Employee updateEmployee(int eid, Employee employee) {
		 Transaction transaction = null;
		 try {
			    transaction = session.beginTransaction();
			    session.merge(employee);  // or update/delete logic
			    transaction.commit();
			    return employee;
}
		 catch(Exception e){
			 if(transaction != null) transaction.rollback();
			    e.printStackTrace();
			    return null;

		 }
	 }
}
