function makeActive(elementId){
	document.getElementById(elementId).style.color="white";	
}